import { useState } from 'react'
import NavbarPage from './Navbar/NavbarPage'
import HomePage from './pages/HomePage'
import LoginPage from './pages/LoginPage'
import SigninPage from './pages/SigninPage'



import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  const [count, setCount] = useState(0)

  return (
  <div>

<BrowserRouter>
<NavbarPage/>
<Routes>

<Route path="/" element={<HomePage/>}></Route>
<Route path="Login" element={<LoginPage/>}></Route>
<Route path="Sigin" element={<SigninPage/>}></Route>

</Routes>

</BrowserRouter>

  </div>
  )
}

export default App
