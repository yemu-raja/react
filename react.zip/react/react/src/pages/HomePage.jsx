import axios from "axios";
import React, { useEffect, useState } from "react";
import Card from '../Navbar/Cards';


function HomePage(){

// useEffect(function,array)

    useEffect(()=>{
        getAllProducts()
    },[])

const [products,setProducts] =useState("")
   
async function getAllProducts() {


const res = await axios.get("https://dummyjson.com/products")
const data = res.data
// console.log(data);
setProducts(data)


}



    return (
<div className="container">
    {/* <button className="btn btn-primary" onClick={getAllProducts}>Get All Products</button> */}
<div className="row g-2">{products && products.products.map((product)=>{

return (
<div className="col">

<Card title={product.title}
      content={product.content}
      image={product.thumbnail}


/>
</div>

)


})

}

</div>
</div>


)

}

export default HomePage